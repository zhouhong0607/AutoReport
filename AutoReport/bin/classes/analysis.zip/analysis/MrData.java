package analysis;

public class MrData
{
	double[] mrRsrp;
	double[] mrRsrq;
	double[] mrPrbNum;
	double[] mrPlrUl6;
	double[] mrPlrUl8;
	double[] mrPlrUl9;
	double[] mrPlrDl6;
	double[] mrPlrDl8;
	double[] mrPlrDl9;
	double[] mrSinrUl;
	
	double expMrRsrp;
	double expMrRsrq;
	double expMrPrbNum;
	double expMrPlrUl;
	double expMrPlrDl;
	double expMrSinrUl;
	
	int indexExpRsrp;
	int indexExpRsrq;
	
	public MrData()
	{
		
	}
	
	
	
//	public double getExpMrRsrp() {
//		return expMrRsrp;
//	}
//
//
//
//	public void setExpMrRsrp(double expMrRsrp) {
//		this.expMrRsrp = expMrRsrp;
//	}
//
//
//
//	public double getExpMrRsrq() {
//		return expMrRsrq;
//	}
//
//
//
//	public void setExpMrRsrq(double expMrRsrq) {
//		this.expMrRsrq = expMrRsrq;
//	}
//
//
//
//	public double getExpMrPrbNum() {
//		return expMrPrbNum;
//	}
//
//
//
//	public void setExpMrPrbNum(double expMrPrbNum) {
//		this.expMrPrbNum = expMrPrbNum;
//	}
//
//
//
//	public double getExpMrPlrUl() {
//		return expMrPlrUl;
//	}
//
//
//
//	public void setExpMrPlrUl(double expMrPlrUl) {
//		this.expMrPlrUl = expMrPlrUl;
//	}
//
//
//
//	public double getExpMrPlrDl() {
//		return expMrPlrDl;
//	}
//
//
//
//	public void setExpMrPlrDl(double expMrPlrDl) {
//		this.expMrPlrDl = expMrPlrDl;
//	}
//
//
//
//	public double getExpMrSinrUl() {
//		return expMrSinrUl;
//	}
//
//
//
//	public void setExpMrSinrUl(double expMrSinrUl) {
//		this.expMrSinrUl = expMrSinrUl;
//	}
//
//
//
//	
//	
//	
//	
//	public double[] getMrPlrUl6() {
//		return mrPlrUl6;
//	}
//
//
//	public void setMrPlrUl6(double[] mrPlrUl6) {
//		this.mrPlrUl6 = mrPlrUl6;
//	}
//
//
//	public double[] getMrPlrUl8() {
//		return mrPlrUl8;
//	}
//
//
//	public void setMrPlrUl8(double[] mrPlrUl8) {
//		this.mrPlrUl8 = mrPlrUl8;
//	}
//
//
//	public double[] getMrPlrUl9() {
//		return mrPlrUl9;
//	}
//
//
//	public void setMrPlrUl9(double[] mrPlrUl9) {
//		this.mrPlrUl9 = mrPlrUl9;
//	}
//
//
//	public double[] getMrPlrDl6() {
//		return mrPlrDl6;
//	}
//
//
//	public void setMrPlrDl6(double[] mrPlrDl6) {
//		this.mrPlrDl6 = mrPlrDl6;
//	}
//
//
//	public double[] getMrPlrDl8() {
//		return mrPlrDl8;
//	}
//
//
//	public void setMrPlrDl8(double[] mrPlrDl8) {
//		this.mrPlrDl8 = mrPlrDl8;
//	}
//
//
//	public double[] getMrPlrDl9() {
//		return mrPlrDl9;
//	}
//
//
//	public void setMrPlrDl9(double[] mrPlrDl9) {
//		this.mrPlrDl9 = mrPlrDl9;
//	}
//	
//	
//	
//	public double[] getMrRsrp() {
//		return mrRsrp;
//	}
//	public void setMrRsrp(double[] mrRsrp) {
//		this.mrRsrp = mrRsrp;
//	}
//	public double[] getMrRsrq() {
//		return mrRsrq;
//	}
//	public void setMrRsrq(double[] mrRsrq) {
//		this.mrRsrq = mrRsrq;
//	}
//	public double[] getMrPrbNum() {
//		return mrPrbNum;
//	}
//	public void setMrPrbNum(double[] mrPrbNum) {
//		this.mrPrbNum = mrPrbNum;
//	}
//
//	public double[] getMrSinrUl() {
//		return mrSinrUl;
//	}
//	public void setMrSinrUl(double[] mrSinrUl) {
//		this.mrSinrUl = mrSinrUl;
//	}
//	
}
